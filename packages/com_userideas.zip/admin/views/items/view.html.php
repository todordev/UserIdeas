<?php
/**
 * @package      ITPrism Components
 * @subpackage   UserFeedback
 * @author       Todor Iliev
 * @copyright    Copyright (C) 2010 Todor Iliev <todor@itprism.com>. All rights reserved.
 * @license      http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * UserFeedback is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// no direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

class UserFeedbackViewItems extends JView {
    
    protected $items;
    protected $pagination;
    protected $state;
    
    public function display($tpl = null){
        
        $this->state      = $this->get('State');
        $this->items      = $this->get('Items');
        $this->pagination = $this->get('Pagination');
        
        // Prepare filters
        $this->listOrder  = $this->escape($this->state->get('list.ordering'));
        $this->listDirn   = $this->escape($this->state->get('list.direction'));
        $this->saveOrder  = (strcmp($this->listOrder, 'a.title') != 0 ) ? false : true;
        
        // Add submenu
        UserFeedbackHelper::addSubmenu($this->getName());
        
        // Prepare actions
        $this->addToolbar();
        $this->setDocument();
        
        parent::display($tpl);
    }
    
    /**
     * Add the page title and toolbar.
     *
     * @since   1.6
     */
    protected function addToolbar(){
        
        // Set toolbar items for the page
        JToolBarHelper::title(JText::_('COM_USERFEEDBACK_ITEMS_MANAGER'), 'itp-items');
        JToolBarHelper::addNew('item.add');
        JToolBarHelper::editList('item.edit');
        JToolBarHelper::divider();
        JToolBarHelper::publishList("items.publish");
        JToolBarHelper::unpublishList("items.unpublish");
        JToolBarHelper::divider();
        JToolBarHelper::deleteList(JText::_("COM_USERFEEDBACK_DELETE_ITEMS_QUESTION"), "items.delete");
        JToolBarHelper::divider();
        JToolBarHelper::custom('items.backToDashboard', "itp-dashboard-back", "", JText::_("COM_USERFEEDBACK_DASHBOARD"), false);
        
    }
    
	/**
	 * Method to set up the document properties
	 *
	 * @return void
	 */
	protected function setDocument() {
		$this->document->setTitle(JText::_('COM_USERFEEDBACK_ITEMS_MANAGER'));
	}

}